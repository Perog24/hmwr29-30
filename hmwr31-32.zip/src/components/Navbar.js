import { NavLink } from "react-router-dom";

const Navbar = () => {

   return (
      <nav >
         <NavLink >Home</NavLink>
      </nav>
   )
}
export default Navbar;